<?php
/**
 * Auth Helper
 * Mengelola session dan pembatasan akses berdasarkan role
 */

// Mulai session jika belum dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Cek apakah pengguna sudah login
 * @return bool
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Mendapatkan role pengguna yang sedang login
 * @return string|null
 */
function getUserRole() {
    return $_SESSION['user_role'] ?? null;
}

/**
 * Mendapatkan ID pengguna yang sedang login
 * @return int|null
 */
function getUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Mendapatkan nama pengguna yang sedang login
 * @return string|null
 */
function getUserName() {
    return $_SESSION['user_name'] ?? null;
}

/**
 * Mengharuskan pengguna sudah login
 * Jika belum login, redirect ke halaman login
 */
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /ppks_tv/login.php');
        exit;
    }
}

/**
 * Mengharuskan pengguna memiliki role tertentu
 * @param string|array $roles - Role yang diizinkan (string atau array)
 */
function requireRole($roles) {
    requireLogin();
    
    if (is_string($roles)) {
        $roles = [$roles];
    }
    
    if (!in_array(getUserRole(), $roles)) {
        // Redirect ke dashboard yang sesuai dengan role
        $redirect = '/ppks_tv/login.php';
        switch (getUserRole()) {
            case 'admin':
                $redirect = '/ppks_tv/admin/dashboard.php';
                break;
            case 'ppks':
                $redirect = '/ppks_tv/ppks/dashboard.php';
                break;
            case 'requester':
                $redirect = '/ppks_tv/requester/dashboard.php';
                break;
        }
        header("Location: $redirect");
        exit;
    }
}

/**
 * Redirect ke dashboard sesuai role
 */
function redirectToDashboard() {
    switch (getUserRole()) {
        case 'admin':
            header('Location: /ppks_tv/admin/dashboard.php');
            break;
        case 'ppks':
            header('Location: /ppks_tv/ppks/dashboard.php');
            break;
        case 'requester':
            header('Location: /ppks_tv/requester/dashboard.php');
            break;
        default:
            header('Location: /ppks_tv/login.php');
            break;
    }
    exit;
}
