<?php
/**
 * Header Template
 * Template header dengan sidebar navigation responsif
 * Digunakan di seluruh halaman sistem
 */

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';

requireLogin();

$currentRole = getUserRole();
$currentUser = getUserName();
$unreadCount = countUnreadNotifications(getUserId());
$notifications = getNotifications(getUserId(), 5);

// Tentukan halaman aktif
$currentPage = basename($_SERVER['PHP_SELF']);
$currentDir  = basename(dirname($_SERVER['PHP_SELF']));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PPKS TV - Sistem Pengelolaan Konten</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="/ppks_tv/assets/css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Sidebar -->
    <nav id="sidebar" class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <img src="/ppks_tv/assets/logo.png" alt="PPKS TV" class="sidebar-logo-img">
            </div>
        </div>
        <ul class="sidebar-nav">
            <?php if ($currentRole === 'admin'): ?>
                <!-- Menu Admin -->
                <li class="nav-item">
                    <a href="/ppks_tv/admin/dashboard.php" class="nav-link <?= ($currentPage == 'dashboard.php' && $currentDir == 'admin') ? 'active' : '' ?>">
                        <i class="bi bi-speedometer2"></i> <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="/ppks_tv/admin/users.php" class="nav-link <?= $currentPage == 'users.php' ? 'active' : '' ?>">
                        <i class="bi bi-people"></i> <span>Kelola Pengguna</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="/ppks_tv/admin/projects.php" class="nav-link <?= ($currentPage == 'projects.php' && $currentDir == 'admin') ? 'active' : '' ?>">
                        <i class="bi bi-folder2-open"></i> <span>Monitoring Proyek</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="/ppks_tv/admin/settings.php" class="nav-link <?= $currentPage == 'settings.php' ? 'active' : '' ?>">
                        <i class="bi bi-gear"></i> <span>Pengaturan SMTP</span>
                    </a>
                </li>
            <?php elseif ($currentRole === 'ppks'): ?>
                <!-- Menu PPKS -->
                <li class="nav-item">
                    <a href="/ppks_tv/ppks/dashboard.php" class="nav-link <?= ($currentPage == 'dashboard.php' && $currentDir == 'ppks') ? 'active' : '' ?>">
                        <i class="bi bi-speedometer2"></i> <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="/ppks_tv/ppks/manage_projects.php" class="nav-link <?= $currentPage == 'manage_projects.php' ? 'active' : '' ?>">
                        <i class="bi bi-kanban"></i> <span>Kelola Proyek</span>
                    </a>
                </li>
            <?php elseif ($currentRole === 'requester'): ?>
                <!-- Menu Requester -->
                <li class="nav-item">
                    <a href="/ppks_tv/requester/dashboard.php" class="nav-link <?= ($currentPage == 'dashboard.php' && $currentDir == 'requester') ? 'active' : '' ?>">
                        <i class="bi bi-speedometer2"></i> <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="/ppks_tv/requester/create_request.php" class="nav-link <?= $currentPage == 'create_request.php' ? 'active' : '' ?>">
                        <i class="bi bi-plus-square"></i> <span>Buat Permintaan</span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
        <div class="sidebar-footer">
            <a href="/ppks_tv/logout.php" class="nav-link text-danger">
                <i class="bi bi-box-arrow-left"></i> <span>Keluar</span>
            </a>
        </div>
    </nav>

    <!-- Main Content Wrapper -->
    <div id="main-content" class="main-content">
        <!-- Topbar -->
        <nav class="topbar">
            <button class="btn btn-link sidebar-toggle" id="sidebarToggle">
                <i class="bi bi-list"></i>
            </button>
            <div class="topbar-right">
                <!-- Notifikasi -->
                <div class="dropdown me-3">
                    <button class="btn btn-link position-relative" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-bell fs-5"></i>
                        <?php if ($unreadCount > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                <?= $unreadCount > 9 ? '9+' : $unreadCount ?>
                            </span>
                        <?php endif; ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end notification-dropdown">
                        <li class="dropdown-header d-flex justify-content-between align-items-center">
                            <strong>Notifikasi</strong>
                            <?php if ($unreadCount > 0): ?>
                                <a href="/ppks_tv/includes/mark_read.php" class="text-decoration-none small">Tandai semua dibaca</a>
                            <?php endif; ?>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <?php if (empty($notifications)): ?>
                            <li class="dropdown-item text-center text-muted py-3">
                                <i class="bi bi-bell-slash"></i> Tidak ada notifikasi
                            </li>
                        <?php else: ?>
                            <?php foreach ($notifications as $notif): ?>
                                <li>
                                    <a class="dropdown-item notification-item <?= $notif['is_read'] ? '' : 'unread' ?>" href="#">
                                        <div class="notification-text"><?= sanitize($notif['message']) ?></div>
                                        <small class="text-muted"><?= formatTanggal($notif['created_at']) ?></small>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>
                <!-- User Menu -->
                <div class="dropdown">
                    <button class="btn btn-link user-menu" data-bs-toggle="dropdown">
                        <div class="user-avatar">
                            <i class="bi bi-person-circle"></i>
                        </div>
                        <div class="user-info d-none d-md-block">
                            <span class="user-name"><?= sanitize($currentUser) ?></span>
                            <span class="user-role"><?= ucfirst($currentRole) ?></span>
                        </div>
                        <i class="bi bi-chevron-down d-none d-md-inline"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <a class="dropdown-item" href="/ppks_tv/logout.php">
                                <i class="bi bi-box-arrow-left"></i> Keluar
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Page Content -->
        <div class="content-wrapper">
            <?= showFlash() ?>
