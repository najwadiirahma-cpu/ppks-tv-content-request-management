<?php
/**
 * Fungsi-fungsi Umum (Helper Functions)
 * Berisi fungsi utilitas yang digunakan di seluruh sistem
 */

require_once __DIR__ . '/../config/database.php';

/**
 * Sanitasi input untuk mencegah XSS
 * @param string $data
 * @return string
 */
function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Redirect ke URL tertentu
 * @param string $url
 */
function redirect($url) {
    header("Location: $url");
    exit;
}

/**
 * Generate CSRF token
 * @return string
 */
function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Validasi CSRF token
 * @param string $token
 * @return bool
 */
function validateCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Menghasilkan badge HTML berdasarkan status
 * @param string $status
 * @return string
 */
function statusBadge($status) {
    $badges = [
        'pending'     => '<span class="badge bg-warning text-dark">Menunggu</span>',
        'approved'    => '<span class="badge bg-info text-dark">Disetujui</span>',
        'on_progress' => '<span class="badge bg-primary">Dalam Proses</span>',
        'review'      => '<span class="badge bg-secondary">Review</span>',
        'completed'   => '<span class="badge bg-success">Selesai</span>',
        'rejected'    => '<span class="badge bg-danger">Ditolak</span>',
    ];
    return $badges[$status] ?? '<span class="badge bg-dark">' . sanitize($status) . '</span>';
}

/**
 * Membuat notifikasi internal
 * @param int $userId - ID pengguna tujuan
 * @param string $message - Isi notifikasi
 */
function createNotification($userId, $message) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
    $stmt->bind_param("is", $userId, $message);
    $stmt->execute();
    $stmt->close();
}

/**
 * Menghitung notifikasi yang belum dibaca
 * @param int $userId
 * @return int
 */
function countUnreadNotifications($userId) {
    global $conn;
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $result['total'];
}

/**
 * Mendapatkan daftar notifikasi
 * @param int $userId
 * @param int $limit
 * @return array
 */
function getNotifications($userId, $limit = 10) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?");
    $stmt->bind_param("ii", $userId, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    $notifications = [];
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();
    return $notifications;
}

/**
 * Menandai notifikasi sebagai sudah dibaca
 * @param int $notificationId
 * @param int $userId
 */
function markNotificationRead($notificationId, $userId) {
    global $conn;
    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $notificationId, $userId);
    $stmt->execute();
    $stmt->close();
}

/**
 * Menandai semua notifikasi sebagai sudah dibaca
 * @param int $userId
 */
function markAllNotificationsRead($userId) {
    global $conn;
    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->close();
}

/**
 * Upload file dengan validasi
 * @param array $file - $_FILES element
 * @param string $type - Tipe file (script, design, video)
 * @return string|false - Nama file jika berhasil, false jika gagal
 */
function uploadFile($file, $type) {
    // Ekstensi yang diizinkan per tipe
    $allowedExtensions = [
        'script' => ['pdf', 'doc', 'docx', 'txt'],
        'design' => ['jpg', 'jpeg', 'png', 'psd', 'ai', 'svg'],
        'video'  => ['mp4', 'avi', 'mov', 'mkv', 'wmv'],
    ];

    // Ukuran maksimum per tipe (dalam bytes)
    $maxSizes = [
        'script' => 10 * 1024 * 1024,   // 10 MB
        'design' => 20 * 1024 * 1024,    // 20 MB
        'video'  => 500 * 1024 * 1024,   // 500 MB
    ];

    if (!isset($allowedExtensions[$type])) {
        return false;
    }

    // Cek error upload
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }

    // Cek ekstensi file
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExtensions[$type])) {
        return false;
    }

    // Cek ukuran file
    if ($file['size'] > $maxSizes[$type]) {
        return false;
    }

    // Generate nama unik
    $fileName = uniqid('file_') . '_' . time() . '.' . $ext;
    $uploadDir = __DIR__ . '/../uploads/' . $type . '/';

    // Buat folder jika belum ada
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    // Pindahkan file
    if (move_uploaded_file($file['tmp_name'], $uploadDir . $fileName)) {
        return $fileName;
    }

    return false;
}

/**
 * Mendapatkan pengaturan dari tabel settings
 * @param string $key
 * @return string|null
 */
function getSetting($key) {
    global $conn;
    $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
    $stmt->bind_param("s", $key);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $result['setting_value'] ?? null;
}

/**
 * Menyimpan pengaturan ke tabel settings
 * @param string $key
 * @param string $value
 */
function saveSetting($key, $value) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    $stmt->bind_param("sss", $key, $value, $value);
    $stmt->execute();
    $stmt->close();
}

/**
 * Mengirim email menggunakan PHPMailer
 * @param string $to - Email tujuan
 * @param string $subject - Subjek email
 * @param string $body - Isi email (HTML)
 * @return bool
 */
function sendEmail($to, $subject, $body) {
    // Cek apakah PHPMailer tersedia
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (!file_exists($autoloadPath)) {
        error_log("PHPMailer belum diinstall. Jalankan: composer install");
        return false;
    }

    require_once $autoloadPath;

    $mail = new PHPMailer\PHPMailer\PHPMailer(true);

    try {
        // Konfigurasi SMTP dari settings
        $mail->isSMTP();
        $mail->Host       = getSetting('smtp_host') ?: 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = getSetting('smtp_username') ?: '';
        $mail->Password   = getSetting('smtp_password') ?: '';
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = getSetting('smtp_port') ?: 587;
        $mail->CharSet    = 'UTF-8';

        // Pengirim
        $fromEmail = getSetting('smtp_from_email') ?: 'noreply@ppkstv.com';
        $fromName  = getSetting('smtp_from_name') ?: 'PPKS TV';
        $mail->setFrom($fromEmail, $fromName);

        // Penerima
        $mail->addAddress($to);

        // Konten email
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Gagal mengirim email: " . $mail->ErrorInfo);
        return false;
    }
}

/**
 * Format tanggal ke format Indonesia
 * @param string $date
 * @return string
 */
function formatTanggal($date) {
    if (empty($date)) return '-';
    $bulan = [
        1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    $timestamp = strtotime($date);
    $hari = date('d', $timestamp);
    $bln = (int)date('m', $timestamp);
    $tahun = date('Y', $timestamp);
    $jam = date('H:i', $timestamp);
    return "$hari $bulan[$bln] $tahun, $jam";
}

/**
 * Pesan flash - Set
 * @param string $type - success, danger, warning, info
 * @param string $message
 */
function setFlash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message,
    ];
}

/**
 * Pesan flash - Tampilkan
 * @return string HTML alert atau kosong
 */
function showFlash() {
    if (isset($_SESSION['flash'])) {
        $type = $_SESSION['flash']['type'];
        $message = $_SESSION['flash']['message'];
        unset($_SESSION['flash']);
        return '<div class="alert alert-' . $type . ' alert-dismissible fade show" role="alert">'
            . $message
            . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>'
            . '</div>';
    }
    return '';
}
