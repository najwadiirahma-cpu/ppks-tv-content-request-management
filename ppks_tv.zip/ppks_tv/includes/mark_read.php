<?php
/**
 * Menandai semua notifikasi sebagai sudah dibaca
 */
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';

requireLogin();
markAllNotificationsRead(getUserId());

// Redirect kembali ke halaman sebelumnya
$referer = $_SERVER['HTTP_REFERER'] ?? '/ppks_tv/';
header("Location: $referer");
exit;
