<?php
/**
 * Halaman Logout
 * Menghapus session dan redirect ke halaman login
 */

session_start();
$_SESSION = [];
session_destroy();
header('Location: /ppks_tv/login.php');
exit;
