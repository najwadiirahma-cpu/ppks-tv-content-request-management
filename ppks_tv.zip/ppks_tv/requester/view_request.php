<?php
/**
 * Lihat Detail Request (Requester)
 * Menampilkan detail permintaan, status, file, video final, dan komentar
 */

require_once __DIR__ . '/../includes/header.php';
requireRole('requester');

$csrfToken = generateCsrfToken();
$requestId = (int)($_GET['id'] ?? 0);
$userId = getUserId();

if ($requestId <= 0) {
    redirect('/ppks_tv/requester/dashboard.php');
}

// Ambil data request (pastikan milik user yang login)
$stmt = $conn->prepare("
    SELECT cr.*, p.id as project_id, p.status as project_status, p.final_video,
           p.pic_id, pic.name as pic_name
    FROM content_requests cr
    LEFT JOIN projects p ON p.request_id = cr.id
    LEFT JOIN users pic ON p.pic_id = pic.id
    WHERE cr.id = ? AND cr.created_by = ?
");
$stmt->bind_param("ii", $requestId, $userId);
$stmt->execute();
$request = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$request) {
    setFlash('danger', 'Permintaan tidak ditemukan.');
    redirect('/ppks_tv/requester/dashboard.php');
}

// Proses komentar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $request['project_id']) {
    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
        setFlash('danger', 'Token keamanan tidak valid.');
        redirect("/ppks_tv/requester/view_request.php?id=$requestId");
    }

    $commentText = trim($_POST['comment_text'] ?? '');
    if (!empty($commentText)) {
        $stmtC = $conn->prepare("INSERT INTO comments (project_id, user_id, comment_text) VALUES (?, ?, ?)");
        $stmtC->bind_param("iis", $request['project_id'], $userId, $commentText);
        $stmtC->execute();
        $stmtC->close();

        // Notifikasi ke PIC
        if ($request['pic_id']) {
            createNotification($request['pic_id'], 
                "Komentar baru dari requester pada proyek #{$request['project_id']}");
        }

        setFlash('success', 'Komentar berhasil ditambahkan.');
    }
    redirect("/ppks_tv/requester/view_request.php?id=$requestId");
}

// File proyek (jika ada)
$files = null;
$comments = null;
if ($request['project_id']) {
    $files = $conn->query("SELECT * FROM project_files WHERE project_id = {$request['project_id']} ORDER BY uploaded_at DESC");
    $comments = $conn->query("
        SELECT c.*, u.name as user_name, r.name as user_role
        FROM comments c
        JOIN users u ON c.user_id = u.id
        JOIN roles r ON u.role_id = r.id
        WHERE c.project_id = {$request['project_id']}
        ORDER BY c.created_at ASC
    ");
}

// Status timeline
$statusSteps = [
    'pending'     => 'Menunggu',
    'approved'    => 'Disetujui',
    'on_progress' => 'Proses',
    'review'      => 'Review',
    'completed'   => 'Selesai',
];
$statusOrder = array_keys($statusSteps);
$currentStatusIndex = array_search($request['status'], $statusOrder);
if ($request['status'] === 'rejected') {
    $currentStatusIndex = -1; // khusus rejected
}
?>

<div class="page-header">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h2><i class="bi bi-eye me-2"></i>Detail Permintaan #<?= $requestId ?></h2>
            <p><?= sanitize($request['content_type']) ?> - <?= sanitize($request['division']) ?></p>
        </div>
        <a href="/ppks_tv/requester/dashboard.php" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
</div>

<?php if ($request['status'] === 'rejected'): ?>
<div class="alert alert-danger">
    <i class="bi bi-x-circle me-2"></i>Permintaan ini telah <strong>ditolak</strong>.
</div>
<?php else: ?>
<!-- Status Timeline -->
<div class="card mb-4 fade-in">
    <div class="card-body">
        <h6 class="mb-3"><i class="bi bi-signpost-2 me-2"></i>Progres Status</h6>
        <div class="d-flex align-items-center flex-wrap gap-2">
            <?php foreach ($statusSteps as $key => $label): 
                $index = array_search($key, $statusOrder);
                $isCompleted = $index < $currentStatusIndex;
                $isActive = $index === $currentStatusIndex;
            ?>
                <div class="d-flex align-items-center">
                    <div class="step-circle <?= $isCompleted ? 'bg-blue text-white' : ($isActive ? 'bg-green text-white' : 'bg-light text-muted') ?>" 
                         style="width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.75rem;font-weight:600;
                         <?= $isActive ? 'box-shadow:0 4px 12px rgba(27,143,75,0.3);' : '' ?>
                         <?= $isCompleted ? 'background:#1565C0;color:white;' : '' ?>
                         <?= $isActive ? 'background:#1B8F4B;color:white;' : '' ?>">
                        <?php if ($isCompleted): ?>
                            <i class="bi bi-check"></i>
                        <?php else: ?>
                            <?= $index + 1 ?>
                        <?php endif; ?>
                    </div>
                    <span class="ms-1 me-2 small <?= $isActive ? 'fw-bold text-green' : ($isCompleted ? 'text-blue' : 'text-muted') ?>">
                        <?= $label ?>
                    </span>
                    <?php if ($key !== 'completed'): ?>
                        <div style="width:40px;height:3px;background:<?= $isCompleted ? '#1565C0' : '#e9ecef' ?>;border-radius:2px;" class="me-2"></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="row g-4">
    <div class="col-lg-8">
        <!-- Detail Request -->
        <div class="card mb-4 fade-in">
            <div class="card-header">
                <i class="bi bi-info-circle me-2"></i>Informasi Permintaan
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6"><strong>Email:</strong> <?= sanitize($request['email']) ?></div>
                    <div class="col-md-6"><strong>Divisi:</strong> <?= sanitize($request['division']) ?></div>
                    <div class="col-md-6"><strong>Tipe Konten:</strong> <?= sanitize($request['content_type']) ?></div>
                    <div class="col-md-6"><strong>Durasi:</strong> <?= $request['duration_minutes'] ?> menit</div>
                    <div class="col-md-6"><strong>Deadline:</strong> <?= formatTanggal($request['deadline']) ?></div>
                    <div class="col-md-6"><strong>Tanggal Permintaan:</strong> <?= formatTanggal($request['created_at']) ?></div>
                    <div class="col-12"><strong>Tujuan:</strong><br><?= nl2br(sanitize($request['goals'])) ?></div>
                    <div class="col-md-4"><strong>Jadwal Lokasi:</strong><br><?= sanitize($request['location_schedule'] ?: '-') ?></div>
                    <div class="col-md-4"><strong>Jadwal Shooting:</strong><br><?= sanitize($request['shooting_schedule'] ?: '-') ?></div>
                    <div class="col-md-4"><strong>Jadwal Wawancara:</strong><br><?= sanitize($request['interview_schedule'] ?: '-') ?></div>
                    <div class="col-12"><strong>Detail Proyek:</strong><br><?= nl2br(sanitize($request['detail_project'] ?: '-')) ?></div>
                </div>
            </div>
        </div>

        <!-- Komentar (hanya jika ada proyek) -->
        <?php if ($request['project_id'] && $request['status'] !== 'rejected'): ?>
        <div class="card fade-in">
            <div class="card-header">
                <i class="bi bi-chat-dots me-2"></i>Komentar
            </div>
            <div class="card-body">
                <?php if ($comments && $comments->num_rows > 0): ?>
                    <?php while ($comment = $comments->fetch_assoc()): ?>
                    <div class="comment-item">
                        <div class="d-flex justify-content-between">
                            <span class="comment-author">
                                <?= sanitize($comment['user_name']) ?>
                                <span class="badge bg-secondary ms-1"><?= ucfirst($comment['user_role']) ?></span>
                            </span>
                            <span class="comment-time"><?= formatTanggal($comment['created_at']) ?></span>
                        </div>
                        <div class="comment-text"><?= nl2br(sanitize($comment['comment_text'])) ?></div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p class="text-muted text-center mb-3">Belum ada komentar.</p>
                <?php endif; ?>

                <!-- Form komentar (hanya saat review) -->
                <?php if (in_array($request['status'], ['review', 'on_progress', 'approved'])): ?>
                <form method="POST" class="mt-3">
                    <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                    <div class="mb-2">
                        <textarea class="form-control" name="comment_text" rows="3" 
                                  placeholder="Tulis komentar atau review Anda..." required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary btn-sm">
                        <i class="bi bi-send me-1"></i> Kirim Komentar
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="col-lg-4">
        <!-- Status & PIC -->
        <div class="card mb-4 fade-in">
            <div class="card-header">
                <i class="bi bi-flag me-2"></i>Status
            </div>
            <div class="card-body text-center">
                <div class="mb-3">
                    <?= statusBadge($request['status']) ?>
                </div>
                <?php if ($request['pic_name']): ?>
                <p class="mb-0"><strong>PIC:</strong> <?= sanitize($request['pic_name']) ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Video Final -->
        <?php if ($request['final_video']): ?>
        <div class="card mb-4 fade-in">
            <div class="card-header">
                <i class="bi bi-camera-video me-2"></i>Video Final
            </div>
            <div class="card-body text-center">
                <p class="mb-2 text-muted small">Video final Anda sudah siap!</p>
                <a href="<?= sanitize($request['final_video']) ?>" target="_blank" class="btn btn-success w-100">
                    <i class="bi bi-play-circle me-1"></i> Tonton Video Final
                </a>
            </div>
        </div>
        <?php endif; ?>

        <!-- File Proyek -->
        <?php if ($files && $files->num_rows > 0): ?>
        <div class="card fade-in">
            <div class="card-header">
                <i class="bi bi-paperclip me-2"></i>File Proyek
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <?php while ($file = $files->fetch_assoc()): ?>
                    <div class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <small class="text-muted"><?= ucfirst($file['file_type']) ?></small><br>
                            <span class="small"><?= sanitize($file['file_name']) ?></span>
                        </div>
                        <a href="/ppks_tv/uploads/<?= $file['file_type'] ?>/<?= $file['file_name'] ?>" 
                           class="btn btn-sm btn-outline-primary" target="_blank">
                            <i class="bi bi-download"></i>
                        </a>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
