<?php
/**
 * Form Pengajuan Request Konten (Requester)
 * Semua field sesuai spesifikasi:
 * email, division, goals, content_type, duration_minutes, 
 * deadline, location_schedule, shooting_schedule, interview_schedule, detail_project
 */

require_once __DIR__ . '/../includes/header.php';
requireRole('requester');

$csrfToken = generateCsrfToken();

// Proses submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
        setFlash('danger', 'Token keamanan tidak valid.');
        redirect('/ppks_tv/requester/create_request.php');
    }

    // Ambil dan validasi input
    $email              = trim($_POST['email'] ?? '');
    $division           = $_POST['division'] ?? '';
    $goals              = trim($_POST['goals'] ?? '');
    $contentType        = $_POST['content_type'] ?? '';
    $durationMinutes    = (int)($_POST['duration_minutes'] ?? 0);
    $deadline           = $_POST['deadline'] ?? '';
    $locationSchedule   = trim($_POST['location_schedule'] ?? '');
    $shootingSchedule   = trim($_POST['shooting_schedule'] ?? '');
    $interviewSchedule  = trim($_POST['interview_schedule'] ?? '');
    $detailProject      = trim($_POST['detail_project'] ?? '');

    // Validasi
    $errors = [];
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Email tidak valid.';
    }
    if (empty($division)) {
        $errors[] = 'Divisi wajib dipilih.';
    }
    if (empty($goals)) {
        $errors[] = 'Tujuan konten wajib diisi.';
    }
    if (empty($contentType)) {
        $errors[] = 'Tipe konten wajib dipilih.';
    }
    if ($durationMinutes <= 0) {
        $errors[] = 'Durasi harus lebih dari 0 menit.';
    }
    if (empty($deadline)) {
        $errors[] = 'Deadline wajib diisi.';
    }

    if (empty($errors)) {
        $userId = getUserId();
        $stmt = $conn->prepare("
            INSERT INTO content_requests 
            (email, division, goals, content_type, duration_minutes, deadline, 
             location_schedule, shooting_schedule, interview_schedule, detail_project, created_by) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("ssssisssssi", 
            $email, $division, $goals, $contentType, $durationMinutes, $deadline,
            $locationSchedule, $shootingSchedule, $interviewSchedule, $detailProject, $userId
        );

        if ($stmt->execute()) {
            // Notifikasi ke semua admin
            $admins = $conn->query("SELECT u.id FROM users u JOIN roles r ON u.role_id = r.id WHERE r.name = 'admin'");
            while ($admin = $admins->fetch_assoc()) {
                createNotification($admin['id'], 
                    "Permintaan konten baru dari " . getUserName() . " - " . $contentType);
            }

            setFlash('success', 'Permintaan konten berhasil diajukan! Silakan tunggu persetujuan admin.');
            redirect('/ppks_tv/requester/dashboard.php');
        } else {
            setFlash('danger', 'Gagal mengajukan permintaan. Silakan coba lagi.');
        }
        $stmt->close();
    } else {
        setFlash('danger', implode('<br>', $errors));
    }
}
?>

<div class="page-header">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h2><i class="bi bi-plus-square me-2"></i>Buat Permintaan Konten</h2>
            <p>Isi formulir di bawah untuk mengajukan permintaan produksi konten video.</p>
        </div>
        <a href="/ppks_tv/requester/dashboard.php" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>
</div>

<div class="card fade-in">
    <div class="card-body">
        <form method="POST" id="requestForm">
            <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">

            <div class="row g-3">
                <!-- Email -->
                <div class="col-md-6">
                    <label class="form-label">Email Kontak <span class="text-danger">*</span></label>
                    <input type="email" class="form-control" name="email" required
                           placeholder="email@example.com"
                           value="<?= sanitize($_POST['email'] ?? '') ?>">
                </div>

                <!-- Divisi -->
                <div class="col-md-6">
                    <label class="form-label">Divisi <span class="text-danger">*</span></label>
                    <select class="form-select" name="division" required>
                        <option value="">-- Pilih Divisi --</option>
                        <option value="Divisi Riset" <?= ($_POST['division'] ?? '') === 'Divisi Riset' ? 'selected' : '' ?>>Divisi Riset</option>
                        <option value="Divisi Operasional" <?= ($_POST['division'] ?? '') === 'Divisi Operasional' ? 'selected' : '' ?>>Divisi Operasional</option>
                        <option value="Divisi Pemasaran" <?= ($_POST['division'] ?? '') === 'Divisi Pemasaran' ? 'selected' : '' ?>>Divisi Pemasaran</option>
                        <option value="Divisi Administrasi" <?= ($_POST['division'] ?? '') === 'Divisi Administrasi' ? 'selected' : '' ?>>Divisi Administrasi</option>
                    </select>
                </div>

                <!-- Tujuan -->
                <div class="col-12">
                    <label class="form-label">Tujuan Konten <span class="text-danger">*</span></label>
                    <textarea class="form-control" name="goals" rows="3" required
                              placeholder="Jelaskan tujuan pembuatan konten ini..."><?= sanitize($_POST['goals'] ?? '') ?></textarea>
                </div>

                <!-- Tipe Konten -->
                <div class="col-md-6">
                    <label class="form-label">Tipe Konten <span class="text-danger">*</span></label>
                    <select class="form-select" name="content_type" required>
                        <option value="">-- Pilih Tipe --</option>
                        <option value="Long Video" <?= ($_POST['content_type'] ?? '') === 'Long Video' ? 'selected' : '' ?>>Long Video</option>
                        <option value="Reels" <?= ($_POST['content_type'] ?? '') === 'Reels' ? 'selected' : '' ?>>Reels</option>
                        <option value="Wawancara" <?= ($_POST['content_type'] ?? '') === 'Wawancara' ? 'selected' : '' ?>>Wawancara</option>
                        <option value="Promosi" <?= ($_POST['content_type'] ?? '') === 'Promosi' ? 'selected' : '' ?>>Promosi</option>
                        <option value="Tutorial" <?= ($_POST['content_type'] ?? '') === 'Tutorial' ? 'selected' : '' ?>>Tutorial</option>
                        <option value="Video Penelitian/Profile" <?= ($_POST['content_type'] ?? '') === 'Video Penelitian/Profile' ? 'selected' : '' ?>>Video Penelitian/Profile</option>
                    </select>
                </div>

                <!-- Durasi -->
                <div class="col-md-3">
                    <label class="form-label">Durasi (menit) <span class="text-danger">*</span></label>
                    <input type="number" class="form-control" name="duration_minutes" min="1" required
                           placeholder="contoh: 5"
                           value="<?= sanitize($_POST['duration_minutes'] ?? '') ?>">
                </div>

                <!-- Deadline -->
                <div class="col-md-3">
                    <label class="form-label">Deadline <span class="text-danger">*</span></label>
                    <input type="date" class="form-control" name="deadline" required
                           min="<?= date('Y-m-d') ?>"
                           value="<?= sanitize($_POST['deadline'] ?? '') ?>">
                </div>

                <!-- Jadwal Lokasi -->
                <div class="col-md-4">
                    <label class="form-label">Lokasi Shooting</label>
                    <input type="text" class="form-control" name="location_schedule"
                           placeholder="Lokasi shooting yang diinginkan"
                           value="<?= sanitize($_POST['location_schedule'] ?? '') ?>">
                </div>

                <!-- Jadwal Shooting -->
                <div class="col-md-4">
                    <label class="form-label">Jadwal Shooting</label>
                    <input type="date" class="form-control" name="shooting_schedule"
                           value="<?= sanitize($_POST['shooting_schedule'] ?? '') ?>">
                </div>

                <!-- Jadwal Wawancara -->
                <div class="col-md-4">
                    <label class="form-label">Jadwal Wawancara</label>
                    <input type="date" class="form-control" name="interview_schedule"
                           value="<?= sanitize($_POST['interview_schedule'] ?? '') ?>">
                </div>

                <!-- Detail Proyek -->
                <div class="col-12">
                    <label class="form-label">Detail Proyek</label>
                    <textarea class="form-control" name="detail_project" rows="4"
                              placeholder="Jelaskan detail lebih lanjut tentang proyek ini (opsional)..."><?= sanitize($_POST['detail_project'] ?? '') ?></textarea>
                </div>
            </div>

            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-send me-1"></i> Ajukan Permintaan
                </button>
                <a href="/ppks_tv/requester/dashboard.php" class="btn btn-secondary">
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
