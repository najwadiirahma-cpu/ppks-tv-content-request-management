<?php
/**
 * Dashboard Requester
 * Menampilkan daftar permintaan konten yang telah diajukan oleh requester
 */

require_once __DIR__ . '/../includes/header.php';
requireRole('requester');

$userId = getUserId();

// Statistik
$stmt = $conn->prepare("SELECT COUNT(*) as t FROM content_requests WHERE created_by = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$totalReq = $stmt->get_result()->fetch_assoc()['t'];
$stmt->close();

$stmt = $conn->prepare("SELECT COUNT(*) as t FROM content_requests WHERE created_by = ? AND status = 'pending'");
$stmt->bind_param("i", $userId);
$stmt->execute();
$pendingReq = $stmt->get_result()->fetch_assoc()['t'];
$stmt->close();

$stmt = $conn->prepare("SELECT COUNT(*) as t FROM content_requests WHERE created_by = ? AND status IN ('on_progress','review')");
$stmt->bind_param("i", $userId);
$stmt->execute();
$activeReq = $stmt->get_result()->fetch_assoc()['t'];
$stmt->close();

$stmt = $conn->prepare("SELECT COUNT(*) as t FROM content_requests WHERE created_by = ? AND status = 'completed'");
$stmt->bind_param("i", $userId);
$stmt->execute();
$completedReq = $stmt->get_result()->fetch_assoc()['t'];
$stmt->close();

// Daftar permintaan saya
$stmt = $conn->prepare("
    SELECT cr.*, p.id as project_id, p.status as project_status, p.final_video
    FROM content_requests cr
    LEFT JOIN projects p ON p.request_id = cr.id
    WHERE cr.created_by = ?
    ORDER BY cr.created_at DESC
");
$stmt->bind_param("i", $userId);
$stmt->execute();
$myRequests = $stmt->get_result();
$stmt->close();
?>

<div class="page-header">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h2><i class="bi bi-speedometer2 me-2"></i>Dashboard</h2>
            <p>Selamat datang, <?= sanitize(getUserName()) ?>. Berikut status permintaan konten Anda.</p>
        </div>
        <a href="/ppks_tv/requester/create_request.php" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i> Buat Permintaan Baru
        </a>
    </div>
</div>

<!-- Statistik -->
<div class="row g-4 mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="stat-card fade-in">
            <div class="stat-icon blue">
                <i class="bi bi-inbox-fill"></i>
            </div>
            <div class="stat-value"><?= $totalReq ?></div>
            <div class="stat-label">Total Permintaan</div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card fade-in">
            <div class="stat-icon orange">
                <i class="bi bi-hourglass-split"></i>
            </div>
            <div class="stat-value"><?= $pendingReq ?></div>
            <div class="stat-label">Menunggu Persetujuan</div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card fade-in">
            <div class="stat-icon green">
                <i class="bi bi-gear-wide-connected"></i>
            </div>
            <div class="stat-value"><?= $activeReq ?></div>
            <div class="stat-label">Sedang Diproses</div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card fade-in">
            <div class="stat-icon red">
                <i class="bi bi-check2-all"></i>
            </div>
            <div class="stat-value"><?= $completedReq ?></div>
            <div class="stat-label">Selesai</div>
        </div>
    </div>
</div>

<!-- Daftar Permintaan -->
<div class="card fade-in">
    <div class="card-header">
        <i class="bi bi-list-ul me-2"></i>Daftar Permintaan Saya
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tipe Konten</th>
                        <th>Divisi</th>
                        <th>Durasi</th>
                        <th>Deadline</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; while ($req = $myRequests->fetch_assoc()): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= sanitize($req['content_type']) ?></td>
                        <td><?= sanitize($req['division']) ?></td>
                        <td><?= $req['duration_minutes'] ?> menit</td>
                        <td><?= formatTanggal($req['deadline']) ?></td>
                        <td><?= statusBadge($req['status']) ?></td>
                        <td>
                            <a href="/ppks_tv/requester/view_request.php?id=<?= $req['id'] ?>" class="btn btn-sm btn-info">
                                <i class="bi bi-eye me-1"></i> Detail
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    <?php if ($no === 1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">
                            Belum ada permintaan. 
                            <a href="/ppks_tv/requester/create_request.php">Buat permintaan baru</a>.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
