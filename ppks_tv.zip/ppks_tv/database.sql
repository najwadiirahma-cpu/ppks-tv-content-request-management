-- ============================================
-- PPKS TV - Sistem Pengelolaan Konten
-- Database: db_ppkstv
-- ============================================

CREATE DATABASE IF NOT EXISTS db_ppkstv
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE db_ppkstv;

-- ============================================
-- 1. Tabel roles
-- Menyimpan daftar role pengguna
-- ============================================
CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- ============================================
-- 2. Tabel users
-- Menyimpan data pengguna sistem
-- ============================================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- 3. Tabel content_requests
-- Menyimpan permintaan konten dari requester
-- ============================================
CREATE TABLE content_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    division ENUM(
        'Divisi Riset',
        'Divisi Operasional',
        'Divisi Pemasaran',
        'Divisi Administrasi'
    ) NOT NULL,
    goals TEXT NOT NULL,
    content_type ENUM(
        'Long Video',
        'Reels',
        'Wawancara',
        'Promosi',
        'Tutorial',
        'Video Penelitian/Profile'
    ) NOT NULL,
    duration_minutes INT NOT NULL COMMENT 'Durasi dalam satuan menit',
    deadline DATE NOT NULL,
    location_schedule VARCHAR(255) DEFAULT NULL,
    shooting_schedule VARCHAR(255) DEFAULT NULL,
    interview_schedule VARCHAR(255) DEFAULT NULL,
    detail_project TEXT DEFAULT NULL,
    status ENUM(
        'pending',
        'approved',
        'on_progress',
        'review',
        'completed',
        'rejected'
    ) NOT NULL DEFAULT 'pending',
    created_by INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- 4. Tabel projects
-- Menyimpan data proyek produksi konten
-- ============================================
CREATE TABLE projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    request_id INT NOT NULL,
    pic_id INT DEFAULT NULL,
    final_video VARCHAR(255) DEFAULT NULL,
    status ENUM(
        'pending',
        'on_progress',
        'review',
        'completed',
        'rejected'
    ) NOT NULL DEFAULT 'pending',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES content_requests(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (pic_id) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- 5. Tabel project_files
-- Menyimpan file yang diunggah untuk proyek
-- ============================================
CREATE TABLE project_files (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_type ENUM('script', 'design', 'video') NOT NULL,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- 6. Tabel comments
-- Menyimpan komentar pada proyek
-- ============================================
CREATE TABLE comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    user_id INT NOT NULL,
    comment_text TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- 7. Tabel notifications
-- Menyimpan notifikasi internal sistem
-- ============================================
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- 8. Tabel settings
-- Menyimpan konfigurasi SMTP email pengirim
-- ============================================
CREATE TABLE settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT DEFAULT NULL
) ENGINE=InnoDB;

-- ============================================
-- DATA AWAL (SEED)
-- ============================================

-- Insert role default
INSERT INTO roles (name) VALUES
    ('admin'),
    ('ppks'),
    ('requester');

-- Insert akun admin default (password: admin123)
INSERT INTO users (name, username, password, role_id) VALUES
    ('Administrator', 'admin', '$2y$10$7SFwM32ihq8S909zfDka0O.0meaYmFzDRf86kLQa2i0KTyOWLLL4W', 1);
-- Catatan: hash di atas adalah hasil password_hash('admin123', PASSWORD_DEFAULT)
-- Jika hash tidak cocok, jalankan: php -r "echo password_hash('admin123', PASSWORD_DEFAULT);"

-- Insert konfigurasi SMTP default
INSERT INTO settings (setting_key, setting_value) VALUES
    ('smtp_host', 'smtp.gmail.com'),
    ('smtp_port', '587'),
    ('smtp_username', ''),
    ('smtp_password', ''),
    ('smtp_from_email', ''),
    ('smtp_from_name', 'PPKS TV');
