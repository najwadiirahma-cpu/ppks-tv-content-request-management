<?php
/**
 * Kelola Proyek (PPKS)
 * Fitur:
 * - Melihat semua proyek dari request yang disetujui
 * - Menentukan PIC
 * - Mengubah status proyek
 * - Upload file (script, desain, video)
 * - Memberikan komentar
 * - Mengirim link video final ke requester via email
 */

require_once __DIR__ . '/../includes/header.php';
requireRole('ppks');

$csrfToken = generateCsrfToken();

// ============================================
// DETAIL PROYEK (jika ada parameter id)
// ============================================
if (isset($_GET['id'])) {
    $projectId = (int)$_GET['id'];

    // Ambil data proyek
    $stmt = $conn->prepare("
        SELECT p.*, cr.*, cr.status as request_status,
               p.status as project_status,
               u.name as requester_name, u.id as requester_user_id,
               pic.name as pic_name
        FROM projects p
        JOIN content_requests cr ON p.request_id = cr.id
        JOIN users u ON cr.created_by = u.id
        LEFT JOIN users pic ON p.pic_id = pic.id
        WHERE p.id = ?
    ");
    $stmt->bind_param("i", $projectId);
    $stmt->execute();
    $project = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$project) {
        setFlash('danger', 'Proyek tidak ditemukan.');
        redirect('/ppks_tv/ppks/manage_projects.php');
    }

    // ========== PROSES AKSI ==========
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
            setFlash('danger', 'Token keamanan tidak valid.');
            redirect("/ppks_tv/ppks/manage_projects.php?id=$projectId");
        }

        $action = $_POST['action'] ?? '';

        // Ubah status proyek
        if ($action === 'update_status') {
            $newStatus = $_POST['status'] ?? '';
            $allowedStatuses = ['pending', 'on_progress', 'review', 'completed', 'rejected'];
            if (in_array($newStatus, $allowedStatuses)) {
                $stmtU = $conn->prepare("UPDATE projects SET status = ? WHERE id = ?");
                $stmtU->bind_param("si", $newStatus, $projectId);
                $stmtU->execute();

                // Update status request juga
                $stmtR = $conn->prepare("UPDATE content_requests SET status = ? WHERE id = ?");
                $stmtR->bind_param("si", $newStatus, $project['request_id']);
                $stmtR->execute();
                $stmtR->close();

                // Notifikasi ke requester
                createNotification($project['requester_user_id'], 
                    "Status proyek #{$projectId} telah diubah menjadi: " . ucfirst(str_replace('_', ' ', $newStatus)));

                $stmtU->close();
                setFlash('success', 'Status proyek berhasil diperbarui.');
            }
            redirect("/ppks_tv/ppks/manage_projects.php?id=$projectId");
        }

        // Tentukan PIC
        if ($action === 'assign_pic') {
            $picId = (int)($_POST['pic_id'] ?? 0);
            if ($picId > 0) {
                $stmtP = $conn->prepare("UPDATE projects SET pic_id = ? WHERE id = ?");
                $stmtP->bind_param("ii", $picId, $projectId);
                $stmtP->execute();
                $stmtP->close();
                setFlash('success', 'PIC berhasil ditentukan.');
            }
            redirect("/ppks_tv/ppks/manage_projects.php?id=$projectId");
        }

        // Upload file
        if ($action === 'upload_file') {
            $fileType = $_POST['file_type'] ?? '';
            if (in_array($fileType, ['script', 'design', 'video']) && isset($_FILES['file'])) {
                $fileName = uploadFile($_FILES['file'], $fileType);
                if ($fileName) {
                    $stmtF = $conn->prepare("INSERT INTO project_files (project_id, file_name, file_type) VALUES (?, ?, ?)");
                    $stmtF->bind_param("iss", $projectId, $fileName, $fileType);
                    $stmtF->execute();
                    $stmtF->close();

                    createNotification($project['requester_user_id'], 
                        "File baru ($fileType) telah diunggah ke proyek #{$projectId}.");

                    setFlash('success', 'File berhasil diunggah.');
                } else {
                    setFlash('danger', 'Gagal mengunggah file. Periksa format dan ukuran file.');
                }
            }
            redirect("/ppks_tv/ppks/manage_projects.php?id=$projectId");
        }

        // Tambah komentar
        if ($action === 'add_comment') {
            $commentText = trim($_POST['comment_text'] ?? '');
            if (!empty($commentText)) {
                $stmtC = $conn->prepare("INSERT INTO comments (project_id, user_id, comment_text) VALUES (?, ?, ?)");
                $userId = getUserId();
                $stmtC->bind_param("iis", $projectId, $userId, $commentText);
                $stmtC->execute();
                $stmtC->close();

                createNotification($project['requester_user_id'], 
                    "Komentar baru pada proyek #{$projectId} dari " . getUserName());

                setFlash('success', 'Komentar berhasil ditambahkan.');
            }
            redirect("/ppks_tv/ppks/manage_projects.php?id=$projectId");
        }

        // Kirim video final via email
        if ($action === 'send_final') {
            $finalVideo = trim($_POST['final_video'] ?? '');
            if (!empty($finalVideo)) {
                // Simpan link video final
                $stmtV = $conn->prepare("UPDATE projects SET final_video = ?, status = 'completed' WHERE id = ?");
                $stmtV->bind_param("si", $finalVideo, $projectId);
                $stmtV->execute();
                $stmtV->close();

                // Update status request
                $stmtR = $conn->prepare("UPDATE content_requests SET status = 'completed' WHERE id = ?");
                $stmtR->bind_param("i", $project['request_id']);
                $stmtR->execute();
                $stmtR->close();

                // Kirim email ke requester
                $emailBody = "
                <html>
                <body style='font-family: Arial, sans-serif; color: #333;'>
                    <div style='max-width: 600px; margin: 0 auto; padding: 20px;'>
                        <div style='background: #1B8F4B; color: white; padding: 20px; border-radius: 10px 10px 0 0; text-align: center;'>
                            <h2 style='margin: 0;'>🎬 PPKS TV</h2>
                            <p style='margin: 5px 0 0;'>Video Final Anda Siap!</p>
                        </div>
                        <div style='background: #f9f9f9; padding: 24px; border: 1px solid #ddd; border-radius: 0 0 10px 10px;'>
                            <p>Halo <strong>" . sanitize($project['requester_name']) . "</strong>,</p>
                            <p>Video final untuk permintaan konten <strong>" . sanitize($project['content_type']) . "</strong> telah selesai diproduksi.</p>
                            <p><strong>Link Video Final:</strong></p>
                            <p><a href='" . sanitize($finalVideo) . "' style='background: #1B8F4B; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;'>Tonton Video</a></p>
                            <p style='margin-top: 20px; font-size: 0.9em; color: #666;'>Silakan login ke sistem untuk memberikan komentar atau review.</p>
                            <hr style='border: none; border-top: 1px solid #ddd; margin: 20px 0;'>
                            <p style='font-size: 0.8em; color: #999;'>Email ini dikirim secara otomatis oleh sistem PPKS TV.</p>
                        </div>
                    </div>
                </body>
                </html>";

                $emailSent = sendEmail(
                    $project['email'],
                    'Video Final Siap - PPKS TV',
                    $emailBody
                );

                createNotification($project['requester_user_id'], 
                    "Video final proyek #{$projectId} telah tersedia. Silakan cek email atau lihat di sistem.");

                if ($emailSent) {
                    setFlash('success', 'Video final berhasil disimpan dan email notifikasi telah dikirim.');
                } else {
                    setFlash('warning', 'Video final berhasil disimpan, namun email gagal dikirim. Periksa konfigurasi SMTP.');
                }
            }
            redirect("/ppks_tv/ppks/manage_projects.php?id=$projectId");
        }
    }

    // Re-fetch project data setelah aksi
    $stmt = $conn->prepare("
        SELECT p.*, cr.*, cr.status as request_status,
               p.status as project_status,
               u.name as requester_name, u.id as requester_user_id,
               pic.name as pic_name
        FROM projects p
        JOIN content_requests cr ON p.request_id = cr.id
        JOIN users u ON cr.created_by = u.id
        LEFT JOIN users pic ON p.pic_id = pic.id
        WHERE p.id = ?
    ");
    $stmt->bind_param("i", $projectId);
    $stmt->execute();
    $project = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // File proyek
    $files = $conn->query("SELECT * FROM project_files WHERE project_id = $projectId ORDER BY uploaded_at DESC");

    // Komentar
    $comments = $conn->query("
        SELECT c.*, u.name as user_name, r.name as user_role
        FROM comments c
        JOIN users u ON c.user_id = u.id
        JOIN roles r ON u.role_id = r.id
        WHERE c.project_id = $projectId
        ORDER BY c.created_at ASC
    ");

    // Daftar user PPKS untuk PIC
    $ppksUsers = $conn->query("SELECT u.id, u.name FROM users u JOIN roles r ON u.role_id = r.id WHERE r.name = 'ppks'");
    ?>

    <div class="page-header">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h2><i class="bi bi-kanban me-2"></i>Detail Proyek #<?= $projectId ?></h2>
                <p>Kelola proyek: <?= sanitize($project['content_type']) ?> - <?= sanitize($project['division']) ?></p>
            </div>
            <a href="/ppks_tv/ppks/manage_projects.php" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left me-1"></i> Kembali
            </a>
        </div>
    </div>

    <div class="row g-4">
        <!-- Kolom Kiri: Info Proyek -->
        <div class="col-lg-8">
            <!-- Info Request -->
            <div class="card mb-4 fade-in">
                <div class="card-header">
                    <i class="bi bi-info-circle me-2"></i>Informasi Permintaan
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6"><strong>Pemohon:</strong> <?= sanitize($project['requester_name']) ?></div>
                        <div class="col-md-6"><strong>Email:</strong> <?= sanitize($project['email']) ?></div>
                        <div class="col-md-6"><strong>Divisi:</strong> <?= sanitize($project['division']) ?></div>
                        <div class="col-md-6"><strong>Tipe Konten:</strong> <?= sanitize($project['content_type']) ?></div>
                        <div class="col-md-6"><strong>Durasi:</strong> <?= $project['duration_minutes'] ?> menit</div>
                        <div class="col-md-6"><strong>Deadline:</strong> <?= formatTanggal($project['deadline']) ?></div>
                        <div class="col-12"><strong>Tujuan:</strong><br><?= nl2br(sanitize($project['goals'])) ?></div>
                        <div class="col-md-4"><strong>Jadwal Lokasi:</strong><br><?= sanitize($project['location_schedule'] ?: '-') ?></div>
                        <div class="col-md-4"><strong>Jadwal Shooting:</strong><br><?= sanitize($project['shooting_schedule'] ?: '-') ?></div>
                        <div class="col-md-4"><strong>Jadwal Wawancara:</strong><br><?= sanitize($project['interview_schedule'] ?: '-') ?></div>
                        <div class="col-12"><strong>Detail:</strong><br><?= nl2br(sanitize($project['detail_project'] ?: '-')) ?></div>
                    </div>
                </div>
            </div>

            <!-- File Proyek -->
            <div class="card mb-4 fade-in">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-paperclip me-2"></i>File Proyek</span>
                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#uploadModal">
                        <i class="bi bi-upload me-1"></i> Unggah File
                    </button>
                </div>
                <div class="card-body">
                    <?php if ($files->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Nama File</th>
                                    <th>Tipe</th>
                                    <th>Tanggal Unggah</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($file = $files->fetch_assoc()): ?>
                                <tr>
                                    <td><?= sanitize($file['file_name']) ?></td>
                                    <td><span class="badge bg-secondary"><?= ucfirst($file['file_type']) ?></span></td>
                                    <td><?= formatTanggal($file['uploaded_at']) ?></td>
                                    <td>
                                        <a href="/ppks_tv/uploads/<?= $file['file_type'] ?>/<?= $file['file_name'] ?>" 
                                           class="btn btn-sm btn-outline-primary" target="_blank">
                                            <i class="bi bi-download"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                        <p class="text-muted text-center py-3 mb-0">Belum ada file yang diunggah.</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Komentar -->
            <div class="card fade-in">
                <div class="card-header">
                    <i class="bi bi-chat-dots me-2"></i>Komentar
                </div>
                <div class="card-body">
                    <?php while ($comment = $comments->fetch_assoc()): ?>
                    <div class="comment-item">
                        <div class="d-flex justify-content-between">
                            <span class="comment-author">
                                <?= sanitize($comment['user_name']) ?>
                                <span class="badge bg-secondary ms-1"><?= ucfirst($comment['user_role']) ?></span>
                            </span>
                            <span class="comment-time"><?= formatTanggal($comment['created_at']) ?></span>
                        </div>
                        <div class="comment-text"><?= nl2br(sanitize($comment['comment_text'])) ?></div>
                    </div>
                    <?php endwhile; ?>

                    <!-- Form Komentar -->
                    <form method="POST" class="mt-3">
                        <input type="hidden" name="action" value="add_comment">
                        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                        <div class="mb-2">
                            <textarea class="form-control" name="comment_text" rows="3" 
                                      placeholder="Tulis komentar..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary btn-sm">
                            <i class="bi bi-send me-1"></i> Kirim Komentar
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Kolom Kanan: Aksi -->
        <div class="col-lg-4">
            <!-- Status -->
            <div class="card mb-4 fade-in">
                <div class="card-header">
                    <i class="bi bi-flag me-2"></i>Status Proyek
                </div>
                <div class="card-body">
                    <div class="mb-3 text-center">
                        <?= statusBadge($project['project_status']) ?>
                    </div>
                    <form method="POST">
                        <input type="hidden" name="action" value="update_status">
                        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                        <select name="status" class="form-select mb-2">
                            <option value="pending" <?= $project['project_status'] === 'pending' ? 'selected' : '' ?>>Menunggu</option>
                            <option value="on_progress" <?= $project['project_status'] === 'on_progress' ? 'selected' : '' ?>>Dalam Proses</option>
                            <option value="review" <?= $project['project_status'] === 'review' ? 'selected' : '' ?>>Review</option>
                            <option value="completed" <?= $project['project_status'] === 'completed' ? 'selected' : '' ?>>Selesai</option>
                        </select>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-arrow-repeat me-1"></i> Perbarui Status
                        </button>
                    </form>
                </div>
            </div>

            <!-- PIC -->
            <div class="card mb-4 fade-in">
                <div class="card-header">
                    <i class="bi bi-person-badge me-2"></i>Penanggung Jawab (PIC)
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <strong>PIC Saat Ini:</strong>
                        <span class="ms-1"><?= $project['pic_name'] ? sanitize($project['pic_name']) : '<em class="text-muted">Belum ditentukan</em>' ?></span>
                    </div>
                    <form method="POST">
                        <input type="hidden" name="action" value="assign_pic">
                        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                        <select name="pic_id" class="form-select mb-2">
                            <option value="">-- Pilih PIC --</option>
                            <?php while ($ppksUser = $ppksUsers->fetch_assoc()): ?>
                                <option value="<?= $ppksUser['id'] ?>" 
                                        <?= $project['pic_id'] == $ppksUser['id'] ? 'selected' : '' ?>>
                                    <?= sanitize($ppksUser['name']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                        <button type="submit" class="btn btn-info w-100">
                            <i class="bi bi-person-check me-1"></i> Tetapkan PIC
                        </button>
                    </form>
                </div>
            </div>

            <!-- Video Final -->
            <div class="card mb-4 fade-in">
                <div class="card-header">
                    <i class="bi bi-camera-video me-2"></i>Video Final
                </div>
                <div class="card-body">
                    <?php if ($project['final_video']): ?>
                        <p class="small mb-2"><strong>Link:</strong></p>
                        <a href="<?= sanitize($project['final_video']) ?>" target="_blank" class="btn btn-success w-100 mb-2">
                            <i class="bi bi-play-circle me-1"></i> Tonton Video
                        </a>
                    <?php else: ?>
                        <form method="POST">
                            <input type="hidden" name="action" value="send_final">
                            <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                            <div class="mb-2">
                                <label class="form-label">Link Video Final</label>
                                <input type="url" class="form-control" name="final_video" 
                                       placeholder="https://..." required>
                            </div>
                            <button type="submit" class="btn btn-warning w-100" 
                                    onclick="return confirm('Kirim video final dan notifikasi email ke requester?')">
                                <i class="bi bi-send me-1"></i> Kirim Video Final
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Upload File -->
    <div class="modal fade" id="uploadModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="upload_file">
                    <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="bi bi-upload me-2"></i>Unggah File</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Tipe File</label>
                            <select class="form-select" name="file_type" required>
                                <option value="">-- Pilih Tipe --</option>
                                <option value="script">Script (PDF, DOC, DOCX, TXT)</option>
                                <option value="design">Desain (JPG, PNG, PSD, AI, SVG)</option>
                                <option value="video">Video (MP4, AVI, MOV, MKV)</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Pilih File</label>
                            <input type="file" class="form-control" name="file" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-upload me-1"></i> Unggah
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php
    require_once __DIR__ . '/../includes/footer.php';
    exit; // Selesai halaman detail
}

// ============================================
// DAFTAR SEMUA PROYEK
// ============================================
$allProjects = $conn->query("
    SELECT p.*, cr.content_type, cr.division, cr.deadline, cr.email,
           u.name as requester_name, pic.name as pic_name
    FROM projects p
    JOIN content_requests cr ON p.request_id = cr.id
    JOIN users u ON cr.created_by = u.id
    LEFT JOIN users pic ON p.pic_id = pic.id
    ORDER BY p.updated_at DESC
");
?>

<div class="page-header">
    <h2><i class="bi bi-kanban me-2"></i>Kelola Proyek</h2>
    <p>Daftar semua proyek dari permintaan yang telah disetujui.</p>
</div>

<div class="card fade-in">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tipe Konten</th>
                        <th>Pemohon</th>
                        <th>Divisi</th>
                        <th>Deadline</th>
                        <th>PIC</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; while ($p = $allProjects->fetch_assoc()): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= sanitize($p['content_type']) ?></td>
                        <td><?= sanitize($p['requester_name']) ?></td>
                        <td><?= sanitize($p['division']) ?></td>
                        <td><?= formatTanggal($p['deadline']) ?></td>
                        <td><?= $p['pic_name'] ? sanitize($p['pic_name']) : '<span class="text-muted">-</span>' ?></td>
                        <td><?= statusBadge($p['status']) ?></td>
                        <td>
                            <a href="/ppks_tv/ppks/manage_projects.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-info">
                                <i class="bi bi-eye me-1"></i> Detail
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    <?php if ($no === 1): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted py-4">Belum ada proyek.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
