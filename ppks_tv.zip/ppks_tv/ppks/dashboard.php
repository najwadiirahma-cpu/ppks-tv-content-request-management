<?php
/**
 * Dashboard PPKS
 * Menampilkan ringkasan proyek yang ditugaskan dan request yang disetujui
 */

require_once __DIR__ . '/../includes/header.php';
requireRole('ppks');

$userId = getUserId();

// Statistik
$approvedReq  = $conn->query("SELECT COUNT(*) as t FROM content_requests WHERE status IN ('approved','on_progress','review','completed')")->fetch_assoc()['t'];
$myProjects   = $conn->query("SELECT COUNT(*) as t FROM projects WHERE pic_id = $userId")->fetch_assoc()['t'];
$inProgress   = $conn->query("SELECT COUNT(*) as t FROM projects WHERE status = 'on_progress'")->fetch_assoc()['t'];
$reviewCount  = $conn->query("SELECT COUNT(*) as t FROM projects WHERE status = 'review'")->fetch_assoc()['t'];

// Proyek terbaru yang ditugaskan ke saya
$myRecentProjects = $conn->query("
    SELECT p.*, cr.content_type, cr.division, cr.deadline, u.name as requester_name
    FROM projects p
    JOIN content_requests cr ON p.request_id = cr.id
    JOIN users u ON cr.created_by = u.id
    WHERE p.pic_id = $userId
    ORDER BY p.updated_at DESC
    LIMIT 10
");
?>

<div class="page-header">
    <h2><i class="bi bi-speedometer2 me-2"></i>Dashboard PPKS</h2>
    <p>Selamat datang, <?= sanitize(getUserName()) ?>. Berikut ringkasan pekerjaan Anda.</p>
</div>

<!-- Statistik Cards -->
<div class="row g-4 mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="stat-card fade-in">
            <div class="stat-icon green">
                <i class="bi bi-check2-circle"></i>
            </div>
            <div class="stat-value"><?= $approvedReq ?></div>
            <div class="stat-label">Request Disetujui</div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card fade-in">
            <div class="stat-icon blue">
                <i class="bi bi-briefcase-fill"></i>
            </div>
            <div class="stat-value"><?= $myProjects ?></div>
            <div class="stat-label">Proyek Saya</div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card fade-in">
            <div class="stat-icon orange">
                <i class="bi bi-gear-wide-connected"></i>
            </div>
            <div class="stat-value"><?= $inProgress ?></div>
            <div class="stat-label">Dalam Proses</div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card fade-in">
            <div class="stat-icon red">
                <i class="bi bi-eye-fill"></i>
            </div>
            <div class="stat-value"><?= $reviewCount ?></div>
            <div class="stat-label">Menunggu Review</div>
        </div>
    </div>
</div>

<!-- Proyek Saya -->
<div class="card fade-in">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span><i class="bi bi-kanban me-2"></i>Proyek yang Ditugaskan ke Saya</span>
        <a href="/ppks_tv/ppks/manage_projects.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tipe Konten</th>
                        <th>Pemohon</th>
                        <th>Divisi</th>
                        <th>Deadline</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; while ($project = $myRecentProjects->fetch_assoc()): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= sanitize($project['content_type']) ?></td>
                        <td><?= sanitize($project['requester_name']) ?></td>
                        <td><?= sanitize($project['division']) ?></td>
                        <td><?= formatTanggal($project['deadline']) ?></td>
                        <td><?= statusBadge($project['status']) ?></td>
                        <td>
                            <a href="/ppks_tv/ppks/manage_projects.php?id=<?= $project['id'] ?>" class="btn btn-sm btn-info">
                                <i class="bi bi-eye"></i> Detail
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    <?php if ($no === 1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">Belum ada proyek yang ditugaskan.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
