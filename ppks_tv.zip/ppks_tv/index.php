<?php
/**
 * Halaman Index
 * Redirect ke dashboard sesuai role atau ke login jika belum login
 */

require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) {
    redirectToDashboard();
} else {
    header('Location: /ppks_tv/login.php');
    exit;
}
