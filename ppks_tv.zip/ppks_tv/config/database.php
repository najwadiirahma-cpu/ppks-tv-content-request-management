<?php
/**
 * Konfigurasi Koneksi Database
 * Menggunakan MySQLi untuk koneksi ke database db_ppkstv
 */

// Pengaturan database
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'db_ppkstv';

// Membuat koneksi
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

// Set charset ke utf8mb4
$conn->set_charset("utf8mb4");
