<?php
/**
 * Dashboard Admin
 * Menampilkan statistik umum: total pengguna, request, proyek, dll.
 */

require_once __DIR__ . '/../includes/header.php';
requireRole('admin');

// Statistik
$totalUsers    = $conn->query("SELECT COUNT(*) as t FROM users")->fetch_assoc()['t'];
$totalRequests = $conn->query("SELECT COUNT(*) as t FROM content_requests")->fetch_assoc()['t'];
$totalProjects = $conn->query("SELECT COUNT(*) as t FROM projects")->fetch_assoc()['t'];
$pendingReq    = $conn->query("SELECT COUNT(*) as t FROM content_requests WHERE status='pending'")->fetch_assoc()['t'];

// Request terbaru
$recentRequests = $conn->query("
    SELECT cr.*, u.name as requester_name 
    FROM content_requests cr 
    JOIN users u ON cr.created_by = u.id 
    ORDER BY cr.created_at DESC 
    LIMIT 10
");
?>

<div class="page-header">
    <h2><i class="bi bi-speedometer2 me-2"></i>Dashboard Admin</h2>
    <p>Selamat datang, <?= sanitize(getUserName()) ?>. Berikut ringkasan sistem.</p>
</div>

<!-- Statistik Cards -->
<div class="row g-4 mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="stat-card fade-in">
            <div class="stat-icon green">
                <i class="bi bi-people-fill"></i>
            </div>
            <div class="stat-value"><?= $totalUsers ?></div>
            <div class="stat-label">Total Pengguna</div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card fade-in">
            <div class="stat-icon blue">
                <i class="bi bi-inbox-fill"></i>
            </div>
            <div class="stat-value"><?= $totalRequests ?></div>
            <div class="stat-label">Total Permintaan</div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card fade-in">
            <div class="stat-icon orange">
                <i class="bi bi-folder2-open"></i>
            </div>
            <div class="stat-value"><?= $totalProjects ?></div>
            <div class="stat-label">Total Proyek</div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="stat-card fade-in">
            <div class="stat-icon red">
                <i class="bi bi-hourglass-split"></i>
            </div>
            <div class="stat-value"><?= $pendingReq ?></div>
            <div class="stat-label">Menunggu Persetujuan</div>
        </div>
    </div>
</div>

<!-- Tabel Request Terbaru -->
<div class="card fade-in">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span><i class="bi bi-clock-history me-2"></i>Permintaan Terbaru</span>
        <a href="/ppks_tv/admin/projects.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Pemohon</th>
                        <th>Tipe Konten</th>
                        <th>Divisi</th>
                        <th>Deadline</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; while ($row = $recentRequests->fetch_assoc()): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= sanitize($row['requester_name']) ?></td>
                        <td><?= sanitize($row['content_type']) ?></td>
                        <td><?= sanitize($row['division']) ?></td>
                        <td><?= formatTanggal($row['deadline']) ?></td>
                        <td><?= statusBadge($row['status']) ?></td>
                        <td><?= formatTanggal($row['created_at']) ?></td>
                    </tr>
                    <?php endwhile; ?>
                    <?php if ($no === 1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">Belum ada permintaan.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
