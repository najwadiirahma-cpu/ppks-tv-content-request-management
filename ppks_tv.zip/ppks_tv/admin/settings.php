<?php
/**
 * Pengaturan SMTP (Admin)
 * Mengatur email pengirim untuk notifikasi sistem
 */

require_once __DIR__ . '/../includes/header.php';
requireRole('admin');

// Proses simpan pengaturan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
        setFlash('danger', 'Token keamanan tidak valid.');
        redirect('/ppks_tv/admin/settings.php');
    }

    saveSetting('smtp_host', trim($_POST['smtp_host'] ?? ''));
    saveSetting('smtp_port', trim($_POST['smtp_port'] ?? ''));
    saveSetting('smtp_username', trim($_POST['smtp_username'] ?? ''));
    saveSetting('smtp_password', trim($_POST['smtp_password'] ?? ''));
    saveSetting('smtp_from_email', trim($_POST['smtp_from_email'] ?? ''));
    saveSetting('smtp_from_name', trim($_POST['smtp_from_name'] ?? ''));

    setFlash('success', 'Pengaturan SMTP berhasil disimpan.');
    redirect('/ppks_tv/admin/settings.php');
}

$csrfToken = generateCsrfToken();
?>

<div class="page-header">
    <h2><i class="bi bi-gear me-2"></i>Pengaturan SMTP Email</h2>
    <p>Konfigurasi email pengirim untuk notifikasi sistem. Email ini digunakan bersama oleh seluruh tim.</p>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="card fade-in">
            <div class="card-header">
                <i class="bi bi-envelope me-2"></i>Konfigurasi SMTP
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                    
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label">SMTP Host</label>
                            <input type="text" class="form-control" name="smtp_host" 
                                   value="<?= sanitize(getSetting('smtp_host') ?: '') ?>"
                                   placeholder="smtp.gmail.com">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Port</label>
                            <input type="number" class="form-control" name="smtp_port" 
                                   value="<?= sanitize(getSetting('smtp_port') ?: '') ?>"
                                   placeholder="587">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Username SMTP</label>
                            <input type="text" class="form-control" name="smtp_username" 
                                   value="<?= sanitize(getSetting('smtp_username') ?: '') ?>"
                                   placeholder="email@gmail.com">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Password SMTP</label>
                            <input type="password" class="form-control" name="smtp_password" 
                                   value="<?= sanitize(getSetting('smtp_password') ?: '') ?>"
                                   placeholder="App Password">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email Pengirim</label>
                            <input type="email" class="form-control" name="smtp_from_email" 
                                   value="<?= sanitize(getSetting('smtp_from_email') ?: '') ?>"
                                   placeholder="ppkstv@ppks.or.id">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Nama Pengirim</label>
                            <input type="text" class="form-control" name="smtp_from_name" 
                                   value="<?= sanitize(getSetting('smtp_from_name') ?: '') ?>"
                                   placeholder="PPKS TV">
                        </div>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-check-lg me-1"></i> Simpan Pengaturan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card fade-in">
            <div class="card-header">
                <i class="bi bi-info-circle me-2"></i>Panduan
            </div>
            <div class="card-body">
                <p class="small text-muted">
                    <strong>Gmail:</strong> Gunakan App Password dari pengaturan keamanan Google Anda. 
                    Host: <code>smtp.gmail.com</code>, Port: <code>587</code>.
                </p>
                <p class="small text-muted mb-0">
                    <strong>Catatan:</strong> Email ini akan digunakan sebagai pengirim untuk semua notifikasi video final 
                    ke requester. Seluruh anggota tim PPKS dapat menggunakan email ini.
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
