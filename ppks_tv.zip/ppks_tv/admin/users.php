<?php
/**
 * Kelola Pengguna (Admin)
 * CRUD: Tambah, Edit, Hapus pengguna
 * Password di-hash menggunakan password_hash()
 */

require_once __DIR__ . '/../includes/header.php';
requireRole('admin');

// Ambil daftar role
$roles = $conn->query("SELECT * FROM roles ORDER BY id");

// ========== PROSES AKSI ==========

// Tambah pengguna baru
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // Validasi CSRF
    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
        setFlash('danger', 'Token keamanan tidak valid.');
        redirect('/ppks_tv/admin/users.php');
    }

    if ($_POST['action'] === 'add') {
        $name     = trim($_POST['name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $role_id  = (int)($_POST['role_id'] ?? 0);

        if (empty($name) || empty($username) || empty($password) || $role_id === 0) {
            setFlash('danger', 'Semua field wajib diisi.');
        } else {
            // Cek username unik
            $check = $conn->prepare("SELECT id FROM users WHERE username = ?");
            $check->bind_param("s", $username);
            $check->execute();
            if ($check->get_result()->num_rows > 0) {
                setFlash('danger', 'Username sudah digunakan.');
            } else {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO users (name, username, password, role_id) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("sssi", $name, $username, $hashedPassword, $role_id);
                if ($stmt->execute()) {
                    setFlash('success', 'Pengguna berhasil ditambahkan.');
                } else {
                    setFlash('danger', 'Gagal menambahkan pengguna.');
                }
                $stmt->close();
            }
            $check->close();
        }
        redirect('/ppks_tv/admin/users.php');
    }

    // Edit pengguna
    if ($_POST['action'] === 'edit') {
        $id       = (int)($_POST['user_id'] ?? 0);
        $name     = trim($_POST['name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $role_id  = (int)($_POST['role_id'] ?? 0);

        if (empty($name) || empty($username) || $role_id === 0) {
            setFlash('danger', 'Nama, username, dan role wajib diisi.');
        } else {
            // Cek username unik (kecuali user sendiri)
            $check = $conn->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
            $check->bind_param("si", $username, $id);
            $check->execute();
            if ($check->get_result()->num_rows > 0) {
                setFlash('danger', 'Username sudah digunakan oleh pengguna lain.');
            } else {
                if (!empty($password)) {
                    // Update dengan password baru
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("UPDATE users SET name=?, username=?, password=?, role_id=? WHERE id=?");
                    $stmt->bind_param("sssii", $name, $username, $hashedPassword, $role_id, $id);
                } else {
                    // Update tanpa mengubah password
                    $stmt = $conn->prepare("UPDATE users SET name=?, username=?, role_id=? WHERE id=?");
                    $stmt->bind_param("ssii", $name, $username, $role_id, $id);
                }
                if ($stmt->execute()) {
                    setFlash('success', 'Pengguna berhasil diperbarui.');
                } else {
                    setFlash('danger', 'Gagal memperbarui pengguna.');
                }
                $stmt->close();
            }
            $check->close();
        }
        redirect('/ppks_tv/admin/users.php');
    }

    // Hapus pengguna
    if ($_POST['action'] === 'delete') {
        $id = (int)($_POST['user_id'] ?? 0);
        // Jangan hapus diri sendiri
        if ($id === getUserId()) {
            setFlash('danger', 'Anda tidak dapat menghapus akun sendiri.');
        } else {
            $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                setFlash('success', 'Pengguna berhasil dihapus.');
            } else {
                setFlash('danger', 'Gagal menghapus pengguna. Pengguna mungkin masih terkait dengan data lain.');
            }
            $stmt->close();
        }
        redirect('/ppks_tv/admin/users.php');
    }
}

// Ambil daftar pengguna
$users = $conn->query("
    SELECT u.*, r.name AS role_name 
    FROM users u 
    JOIN roles r ON u.role_id = r.id 
    ORDER BY u.created_at DESC
");

$csrfToken = generateCsrfToken();
?>

<div class="page-header d-flex justify-content-between align-items-center">
    <div>
        <h2><i class="bi bi-people me-2"></i>Kelola Pengguna</h2>
        <p>Tambah, edit, dan hapus pengguna sistem.</p>
    </div>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
        <i class="bi bi-plus-lg me-1"></i> Tambah Pengguna
    </button>
</div>

<!-- Tabel Pengguna -->
<div class="card fade-in">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Tanggal Dibuat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; while ($user = $users->fetch_assoc()): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><strong><?= sanitize($user['name']) ?></strong></td>
                        <td><code><?= sanitize($user['username']) ?></code></td>
                        <td>
                            <?php
                            $roleColors = ['admin' => 'bg-danger', 'ppks' => 'bg-primary', 'requester' => 'bg-success'];
                            $color = $roleColors[$user['role_name']] ?? 'bg-secondary';
                            ?>
                            <span class="badge <?= $color ?>"><?= ucfirst($user['role_name']) ?></span>
                        </td>
                        <td><?= formatTanggal($user['created_at']) ?></td>
                        <td>
                            <button class="btn btn-sm btn-info me-1" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#editUserModal"
                                    data-id="<?= $user['id'] ?>"
                                    data-name="<?= sanitize($user['name']) ?>"
                                    data-username="<?= sanitize($user['username']) ?>"
                                    data-role="<?= $user['role_id'] ?>">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <?php if ($user['id'] != getUserId()): ?>
                            <form method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus pengguna ini?')">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                                <button type="submit" class="btn btn-sm btn-danger">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Tambah Pengguna -->
<div class="modal fade" id="addUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-person-plus me-2"></i>Tambah Pengguna</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" class="form-control" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" class="form-control" name="password" required minlength="6">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Role</label>
                        <select class="form-select" name="role_id" required>
                            <option value="">-- Pilih Role --</option>
                            <?php 
                            $roles->data_seek(0);
                            while ($role = $roles->fetch_assoc()): 
                            ?>
                                <option value="<?= $role['id'] ?>"><?= ucfirst($role['name']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-lg me-1"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit Pengguna -->
<div class="modal fade" id="editUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="user_id" id="editUserId">
                <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-pencil-square me-2"></i>Edit Pengguna</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" name="name" id="editName" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" class="form-control" name="username" id="editUsername" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password Baru <small class="text-muted">(kosongkan jika tidak diubah)</small></label>
                        <input type="password" class="form-control" name="password" minlength="6">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Role</label>
                        <select class="form-select" name="role_id" id="editRole" required>
                            <?php 
                            $roles->data_seek(0);
                            while ($role = $roles->fetch_assoc()): 
                            ?>
                                <option value="<?= $role['id'] ?>"><?= ucfirst($role['name']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-lg me-1"></i> Perbarui
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Isi data ke modal edit
    document.getElementById('editUserModal').addEventListener('show.bs.modal', function (event) {
        const button = event.relatedTarget;
        document.getElementById('editUserId').value = button.getAttribute('data-id');
        document.getElementById('editName').value = button.getAttribute('data-name');
        document.getElementById('editUsername').value = button.getAttribute('data-username');
        document.getElementById('editRole').value = button.getAttribute('data-role');
    });
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
