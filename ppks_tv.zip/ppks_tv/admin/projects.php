<?php
/**
 * Monitoring Proyek (Admin)
 * Menampilkan seluruh request dan proyek
 * Admin dapat menyetujui/menolak request dan memonitor status
 */

require_once __DIR__ . '/../includes/header.php';
requireRole('admin');

// Proses aksi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
        setFlash('danger', 'Token keamanan tidak valid.');
        redirect('/ppks_tv/admin/projects.php');
    }

    $action    = $_POST['action'] ?? '';
    $requestId = (int)($_POST['request_id'] ?? 0);

    if ($action === 'approve' && $requestId > 0) {
        // Setujui request dan buat proyek
        $stmt = $conn->prepare("UPDATE content_requests SET status = 'approved' WHERE id = ? AND status = 'pending'");
        $stmt->bind_param("i", $requestId);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            // Buat proyek baru
            $stmt2 = $conn->prepare("INSERT INTO projects (request_id) VALUES (?)");
            $stmt2->bind_param("i", $requestId);
            $stmt2->execute();
            $stmt2->close();

            // Notifikasi ke requester
            $req = $conn->prepare("SELECT created_by FROM content_requests WHERE id = ?");
            $req->bind_param("i", $requestId);
            $req->execute();
            $reqData = $req->get_result()->fetch_assoc();
            $req->close();

            if ($reqData) {
                createNotification($reqData['created_by'], "Permintaan konten #$requestId telah disetujui.");
            }

            setFlash('success', 'Permintaan berhasil disetujui dan proyek telah dibuat.');
        }
        $stmt->close();
    } elseif ($action === 'reject' && $requestId > 0) {
        $stmt = $conn->prepare("UPDATE content_requests SET status = 'rejected' WHERE id = ? AND status = 'pending'");
        $stmt->bind_param("i", $requestId);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            // Notifikasi ke requester
            $req = $conn->prepare("SELECT created_by FROM content_requests WHERE id = ?");
            $req->bind_param("i", $requestId);
            $req->execute();
            $reqData = $req->get_result()->fetch_assoc();
            $req->close();

            if ($reqData) {
                createNotification($reqData['created_by'], "Permintaan konten #$requestId telah ditolak.");
            }

            setFlash('warning', 'Permintaan telah ditolak.');
        }
        $stmt->close();
    }

    redirect('/ppks_tv/admin/projects.php');
}

// Filter status
$filterStatus = $_GET['status'] ?? '';
$whereClause = '';
$params = [];
$types = '';

if (!empty($filterStatus)) {
    $whereClause = " WHERE cr.status = ?";
    $params[] = $filterStatus;
    $types .= 's';
}

// Ambil semua request
$sql = "SELECT cr.*, u.name as requester_name,
        p.id as project_id, p.pic_id, p.status as project_status,
        pic.name as pic_name
        FROM content_requests cr
        JOIN users u ON cr.created_by = u.id
        LEFT JOIN projects p ON p.request_id = cr.id
        LEFT JOIN users pic ON p.pic_id = pic.id
        $whereClause
        ORDER BY cr.created_at DESC";

if (!empty($params)) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $requests = $stmt->get_result();
} else {
    $requests = $conn->query($sql);
}

$csrfToken = generateCsrfToken();
?>

<div class="page-header">
    <h2><i class="bi bi-folder2-open me-2"></i>Monitoring Permintaan & Proyek</h2>
    <p>Kelola seluruh permintaan konten dan pantau progres proyek.</p>
</div>

<!-- Filter -->
<div class="card mb-4">
    <div class="card-body py-3">
        <form method="GET" class="d-flex gap-3 align-items-center flex-wrap">
            <label class="form-label mb-0 fw-semibold">Filter Status:</label>
            <select name="status" class="form-select" style="width: auto;">
                <option value="">Semua Status</option>
                <option value="pending" <?= $filterStatus === 'pending' ? 'selected' : '' ?>>Menunggu</option>
                <option value="approved" <?= $filterStatus === 'approved' ? 'selected' : '' ?>>Disetujui</option>
                <option value="on_progress" <?= $filterStatus === 'on_progress' ? 'selected' : '' ?>>Dalam Proses</option>
                <option value="review" <?= $filterStatus === 'review' ? 'selected' : '' ?>>Review</option>
                <option value="completed" <?= $filterStatus === 'completed' ? 'selected' : '' ?>>Selesai</option>
                <option value="rejected" <?= $filterStatus === 'rejected' ? 'selected' : '' ?>>Ditolak</option>
            </select>
            <button type="submit" class="btn btn-info btn-sm">
                <i class="bi bi-funnel me-1"></i> Filter
            </button>
            <?php if (!empty($filterStatus)): ?>
                <a href="/ppks_tv/admin/projects.php" class="btn btn-outline-secondary btn-sm">Reset</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- Tabel -->
<div class="card fade-in">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Pemohon</th>
                        <th>Tipe Konten</th>
                        <th>Divisi</th>
                        <th>Durasi</th>
                        <th>Deadline</th>
                        <th>Status</th>
                        <th>PIC</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; while ($row = $requests->fetch_assoc()): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= sanitize($row['requester_name']) ?></td>
                        <td><?= sanitize($row['content_type']) ?></td>
                        <td><?= sanitize($row['division']) ?></td>
                        <td><?= $row['duration_minutes'] ?> menit</td>
                        <td><?= formatTanggal($row['deadline']) ?></td>
                        <td><?= statusBadge($row['status']) ?></td>
                        <td><?= $row['pic_name'] ? sanitize($row['pic_name']) : '<span class="text-muted">-</span>' ?></td>
                        <td>
                            <!-- Tombol Detail -->
                            <button class="btn btn-sm btn-outline-primary me-1" data-bs-toggle="modal" 
                                    data-bs-target="#detailModal<?= $row['id'] ?>">
                                <i class="bi bi-eye"></i>
                            </button>
                            <?php if ($row['status'] === 'pending'): ?>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="action" value="approve">
                                <input type="hidden" name="request_id" value="<?= $row['id'] ?>">
                                <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                                <button type="submit" class="btn btn-sm btn-success me-1" title="Setujui"
                                        onclick="return confirm('Setujui permintaan ini?')">
                                    <i class="bi bi-check-lg"></i>
                                </button>
                            </form>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="action" value="reject">
                                <input type="hidden" name="request_id" value="<?= $row['id'] ?>">
                                <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
                                <button type="submit" class="btn btn-sm btn-danger" title="Tolak"
                                        onclick="return confirm('Tolak permintaan ini?')">
                                    <i class="bi bi-x-lg"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>

                    <!-- Modal Detail -->
                    <div class="modal fade" id="detailModal<?= $row['id'] ?>" tabindex="-1">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Detail Permintaan #<?= $row['id'] ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <strong>Pemohon:</strong> <?= sanitize($row['requester_name']) ?>
                                        </div>
                                        <div class="col-md-6">
                                            <strong>Email:</strong> <?= sanitize($row['email']) ?>
                                        </div>
                                        <div class="col-md-6">
                                            <strong>Divisi:</strong> <?= sanitize($row['division']) ?>
                                        </div>
                                        <div class="col-md-6">
                                            <strong>Tipe Konten:</strong> <?= sanitize($row['content_type']) ?>
                                        </div>
                                        <div class="col-md-6">
                                            <strong>Durasi:</strong> <?= $row['duration_minutes'] ?> menit
                                        </div>
                                        <div class="col-md-6">
                                            <strong>Deadline:</strong> <?= formatTanggal($row['deadline']) ?>
                                        </div>
                                        <div class="col-12">
                                            <strong>Tujuan:</strong><br><?= nl2br(sanitize($row['goals'])) ?>
                                        </div>
                                        <div class="col-md-4">
                                            <strong>Jadwal Lokasi:</strong><br><?= sanitize($row['location_schedule'] ?: '-') ?>
                                        </div>
                                        <div class="col-md-4">
                                            <strong>Jadwal Shooting:</strong><br><?= sanitize($row['shooting_schedule'] ?: '-') ?>
                                        </div>
                                        <div class="col-md-4">
                                            <strong>Jadwal Wawancara:</strong><br><?= sanitize($row['interview_schedule'] ?: '-') ?>
                                        </div>
                                        <div class="col-12">
                                            <strong>Detail Proyek:</strong><br><?= nl2br(sanitize($row['detail_project'] ?: '-')) ?>
                                        </div>
                                        <div class="col-md-6">
                                            <strong>Status:</strong> <?= statusBadge($row['status']) ?>
                                        </div>
                                        <div class="col-md-6">
                                            <strong>Tanggal Permintaan:</strong> <?= formatTanggal($row['created_at']) ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                    <?php if ($no === 1): ?>
                    <tr>
                        <td colspan="9" class="text-center text-muted py-4">Tidak ada data permintaan.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
